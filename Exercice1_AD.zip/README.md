# TJFOUZIALEX
 LE Consortium

## Étape 1 : Création d'un repository
Voici une capture d'écran de la création du repository :

![Création d'un repository](2.png)

## Étape 2 : Publication sur GitHub
Voici une capture d'écran de la publication :

![Publication sur GitHub](3.png)

## Étape 3 : Ajout des collaborateurs
Capture d'écran de l'ajout des collaborateurs :

![Ajout des collaborateurs - Étape 1](6.png)

![Ajout des collaborateurs - Étape 2](7.png)

## Étape 4 : Création d'une branche
Capture d'écran de la création d'une branche :

![Création d'une branche - Étape 1](8.png)

![Création d'une branche - Étape 2](9.png)

## Étape 5 : Réalisation de commits depuis le projet local
Capture d'écran des commits :

![Commits locaux - Étape 1](10.png)

![Commits locaux - Étape 2](11.png)

## Étape 6 : Création d'une pull request
Capture d'écran de la pull request :

![Création d'une pull request - Étape 1](12.png)

![Création d'une pull request - Étape 2](13.png)

## Étape 7 : Fusion des branches
Capture d'écran de la fusion des branches :

![Fusion des branches](14.png)